/***
 * Copyright 2015 RAPP
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Authors: Konstantinos Panayiotou
 * Contact: klpanagi@gmail.com
 *
 */

var hop = require('hop');
var path = require('path');
var util = require('util');

const ENV = require(path.join(__dirname, '../env.js'));

var rosbridgeIface = require( path.join(__dirname, '../src/rosbridge/src',
    'Rosbridge.js') );

// USE ANONYMOUS SERVICE
var svcName = 'ca_ros';


function caRos( caParams, svcName, args ){
  console.log('CA Request');

  var rosReq = {};
  for ( var prop in args ){
    rosReq[prop] = args[prop];
  }

  console.log(rosReq);

  return hop.HTTPResponseAsync(
    function( sendResponse ) {
      function ros_callback(data){
        console.log(data);
        var response = data;
        sendResponse( hop.HTTPResponseJson(response) );
      }

      function ros_onerror(e){
        console.log(e);
        var response = {
          error: "Platform Failure. Contact RAPP Developers."
        };
        sendResponse( hop.HTTPResponseJson(response) );
      }

      // Open connection to the CloudAgent.
      var ros = new rosbridgeIface({hostname: caParams.iface.host,
        port: caParams.iface.port,
        reconnect: false, onconnection: function(){
          // Call Service on cennection.
          ros.callService(svcName, rosReq,
            {success: ros_callback, fail: ros_onerror}
            );
        }
      });


    }, this);
}



// Register Service to HOP Server
var svc = new hop.Service(caRos);

// Send to main process.
var msg = {
  svc_name: svcName,
  svc_url: svc.path,
  svc_frame: svc
};
postMessage(msg);
