/***
 * Copyright 2015 RAPP
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *    http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 *
 * Authors: Konstantinos Panayiotou
 * Contact: klpanagi@gmail.com
 *
 */


var hop = require('hop');
var path = require('path');
var util = require('util');

const ENV = require(path.join(__dirname, '../env.js'));

const caDb = require(path.join(process.env.HOME, '.ca_db/cloud_agents.json'));

var svcName = 'ca_req';

var workers = {};
var services = {};


function CAReqHandler( kwargs ){
  // TODO Get token from http package header
  kwargs = kwargs || {};
  var svcName = kwargs.service_name || '';
  var caId = kwargs.ca_id || '';
  var caArgs = kwargs.ca_args || [];

  //console.log(kwargs);
  //console.log(caDb[caId])

  if ( ! svcName ){
    var error = 'Empty \"service_name\" argument';
    var response = {error: error};
    return hop.HTTPResponseJson(response);
  }
  if ( ! caId ){
    var error = 'Empty \"service_name\" argument';
    var response = {error: error};
    return hop.HTTPResponseJson(response);
  }
  // If Cloud Agent Identifier not valid
  if ( ! caDb[caId] ){
    var error = "Not a valid Cloud Agent identifier";
    var response = {
      error: error
    };
    return hop.HTTPResponseJson(response);
  }
  // If Cloud Agent has requested service by name
  if ( caDb[caId].svc.indexOf(svcName) <= -1 ){
    var error = util.format("Cloud Agent %s does not own service %s", caId,
      svcName);
    var response = {
      error: error
    };
    return hop.HTTPResponseJson(response);
  }

  return hop.HTTPResponseAsync(
    function( sendResponse ) {
      console.log(caDb[caId].iface.protocol)
      if ( caDb[caId].iface.protocol == "websocket" ){
        //TODO Call ca_ros service to handle this client request.
        services.ca_ros(caDb[caId], svcName, caArgs).post(function(r){
          sendResponse(r);
        });
      }
    }, this);
}

var svc = new hop.Service(CAReqHandler, svcName);
console.log(util.format("Cloud Agent Request Handler listens @ : %s",
    svcUrl(svc.path)));

createWorker('ca_ros_handler', path.join(__dirname, 'ca_ros_handler.js'));


/** ------------------------------------------------------
 *    Util Functions
 *  ------------------------------------------------------
 */

function createWorker(wname, filepath){
  workers[wname] = new Worker(filepath);
  workers[wname].onmessage = function(msg){
  // TODO parse message
  parseWorkerMsg(msg);
  };
}


function parseWorkerMsg(msg){
  var svcName = '';
  var svcFrame;
  var svcUrlPath = '';
  try{
    svcName = msg.data.svc_name;
    svcFrame = msg.data.svc_frame;
    svcUrlPath = msg.data.svc_url;
    services[svcName] = svcFrame;
  }
  catch(e){
    console.log(e);
    return e;
  }
  console.log(util.format("%s Service listens @ : %s", svcName,
      svcUrl(svcUrlPath)));
  return true;
}

function svcUrl(svcUrlPath){
  var url = util.format('http://%s:%s%s', hop.hostname, hop.port, svcUrlPath);
  return url;
}
