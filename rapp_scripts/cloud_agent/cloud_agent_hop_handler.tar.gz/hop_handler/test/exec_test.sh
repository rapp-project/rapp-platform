#!/bin/bash

testfile=${1}
echo $testfile
cmd="hop -v1 -g1 -w1 ${testfile}"

echo -e "Executing test: ${testfile}"

set -o xtrace
eval $cmd
set +o xtrace
